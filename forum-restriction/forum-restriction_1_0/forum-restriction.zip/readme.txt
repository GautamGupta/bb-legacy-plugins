=== Forum Restriction ===
Tags: forum restrict
Contributors: David Bessler
Requires at least: 0.73
Tested up to: 0.75
Stable Tag: 1.0

== Description ==

Allows you to restrict access to forums to certain individuals.

== Installation ==

Add `forum-restriction.php`  to your `/my-plugins/` directory.

== Configuration ==

Edit the $allowed_in_forum array as indicated in `forum-restriction.php`.
Put forum ids on the left, and allowed users on the right.
Any forums not included will not be restricted.

== Frequently Asked Questions ==

None.  It's early.  I'm sure there will be many suggestions.