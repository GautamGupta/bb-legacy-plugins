=== Image Resizer ===
Contributors: Rhys Wynne
Author URL: http://www.gospelrhys.co.uk/
Plugin URL: 

== Description ==
Image Resizer is a BBPress plugin whereby images that are larger than the width of the forum are resized using CSS. Using the back end, you can set the maximum width of the image. No further configuration necessary.

== Installation ==
Unzip the imagerezier.php into the bb-plugins, and activate it on the dashboard.

== Questions == 
Please put questions on this thread - http://www.gospelrhys.co.uk/2009/05/image-resizer-bbpress-plugin.html

== Change Log ==
2009-05-17 Ver. 0.1   released.