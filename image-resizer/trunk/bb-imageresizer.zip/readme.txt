=== Image Resizer ===
Tags: images, resizer, rhyswynne, resize, post
Tested upto: 1.0 RC-1
Contributors: Rhys Wynne
Plugin Name: Image Resizer
Description: Sets a maximum width for an image
Author: Rhys Wynne
Author URI: http://www.gospelrhys.co.uk/
Plugin URI: http://www.gospelrhys.co.uk/plugins/bbpress-plugins/bbpress-image-resizer-plugin
Version: 0.2
Donate link: http://www.gospelrhys.co.uk/donations/
Requires: 0.73 or higher

== Description ==
Image Resizer is a BBPress plugin whereby images that are larger than the width of the forum are resized using CSS. Using the back end, you can set the maximum width of the image. No further configuration necessary.

It requires <a href="http://bbpress.org/plugins/topic/allow-images/">Allow Images</a> plugin to work. 

Compatible with RC-1!

== Installation ==
Unzip the imagerezier.php into the bb-plugins, and activate it on the dashboard.

== Questions == 
Please put questions on this thread - http://www.gospelrhys.co.uk/2009/05/image-resizer-bbpress-plugin.html

== Change Log ==
2009-05-25 Ver. 0.2 Tested in RC-1
2009-05-17 Ver. 0.1 released.